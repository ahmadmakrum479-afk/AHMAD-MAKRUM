package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.data.local.PitchType
import com.cricketmanager.app.data.local.PlayoffType
import com.cricketmanager.app.data.local.ScoringMode
import com.cricketmanager.app.data.local.TieRule
import com.cricketmanager.app.data.local.TiebreakerCriterion
import com.cricketmanager.app.data.local.TournamentFormat
import com.cricketmanager.app.data.repository.TeamDraft
import com.cricketmanager.app.domain.CricketStatsEngine
import com.cricketmanager.app.ui.i18n.AppLanguage
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.viewmodel.CricketUiState
import com.cricketmanager.app.viewmodel.CricketViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreateTournamentScreen(
    uiState: CricketUiState,
    viewModel: CricketViewModel,
    onBack: () -> Unit,
    onCreated: (Long) -> Unit
) {
    val strings = LocalAppStrings.current
    val isBn = strings.language == AppLanguage.BN

    var name by remember { mutableStateOf("") }
    var logoEmoji by remember { mutableStateOf("🏆") }
    var orgName by remember { mutableStateOf(uiState.activeUser?.organization ?: "") }
    var location by remember { mutableStateOf("Central Ground") }
    val todayDateLabel = remember {
        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
    }
    var startDate by remember { mutableStateOf(todayDateLabel) }
    var oversText by remember { mutableStateOf("20") }
    var playersPerSideText by remember { mutableStateOf("11") }
    var squadSizeText by remember { mutableStateOf("15") }
    var allOutWicketsText by remember { mutableStateOf("10") }
    var allOutManuallyEdited by remember { mutableStateOf(false) }
    var maxOversPerBowlerText by remember { mutableStateOf("4") }
    var rules by remember { mutableStateOf("Standard cricket rules. Wide & No-ball = 1 extra run.") }
    var pointsWinText by remember { mutableStateOf("2") }
    var pointsTieText by remember { mutableStateOf("1") }
    var pointsLossText by remember { mutableStateOf("0") }
    var pointsAbandonText by remember { mutableStateOf("1") }
    var pointsWalkoverText by remember { mutableStateOf("2") }

    var pitchType by remember { mutableStateOf(PitchType.FULL_PITCH) }
    var scoringMode by remember { mutableStateOf(ScoringMode.BALL_BY_BALL) }
    var format by remember { mutableStateOf(TournamentFormat.LEAGUE) }
    var selectedPresetId by remember { mutableStateOf("T20_STANDARD") }
    var tieRule by remember { mutableStateOf(TieRule.SHARE_POINTS) }
    var matchesPerPair by remember { mutableStateOf(1) }
    var playoffType by remember { mutableStateOf(PlayoffType.SEMI_FINAL) }
    var playoffTeamsText by remember { mutableStateOf("4") }
    var leaguePlayersText by remember { mutableStateOf("") }
    var leagueSquadText by remember { mutableStateOf("") }
    var leagueOversText by remember { mutableStateOf("") }
    var playoffPlayersText by remember { mutableStateOf("") }
    var playoffSquadText by remember { mutableStateOf("") }
    var playoffOversText by remember { mutableStateOf("") }
    var finalPlayersText by remember { mutableStateOf("") }
    var finalSquadText by remember { mutableStateOf("") }
    var finalOversText by remember { mutableStateOf("") }
    var mottBatWeightText by remember { mutableStateOf("1.0") }
    var mottBowlWeightText by remember { mutableStateOf("1.0") }
    var mottWktShareText by remember { mutableStateOf("0.6") }
    var mottEconShareText by remember { mutableStateOf("0.4") }
    var mottFinalMultText by remember { mutableStateOf("1.5") }
    val tiebreakerOrder = remember {
        mutableStateListOf("POINTS", "WINS", "NRR", "H2H", "NAME")
    }

    val teamDrafts = remember {
        mutableStateListOf(
            TeamDraft("Royal Tigers", "RYT", "🐯", "Captain 1", "Group A"),
            TeamDraft("Green Falcons", "GRF", "🦅", "Captain 2", "Group A"),
            TeamDraft("City Strikers", "CTS", "⚡", "Captain 3", "Group B"),
            TeamDraft("Metro Kings", "MTK", "👑", "Captain 4", "Group B")
        )
    }

    var newTeamName by remember { mutableStateOf("") }
    var newTeamCaptain by remember { mutableStateOf("") }
    var newTeamGroup by remember { mutableStateOf("Group A") }

    Scaffold(
        topBar = {
            ScreenTopBar(
                title = strings.createTournament,
                subtitle = if (isBn) "টুর্নামেন্ট, দল ও নিয়ম সেট করুন" else "Configure rules, format, scoring & teams",
                onBack = onBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = if (isBn) "১. টুর্নামেন্টের তথ্য" else "1. Tournament Identity",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = logoEmoji,
                                onValueChange = { logoEmoji = it.take(2) },
                                label = { Text("Logo") },
                                modifier = Modifier.weight(0.25f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = name,
                                onValueChange = { name = it },
                                label = { Text(if (isBn) "টুর্নামেন্টের নাম *" else "Tournament Name *") },
                                modifier = Modifier.weight(0.75f),
                                singleLine = true
                            )
                        }
                        OutlinedTextField(
                            value = orgName,
                            onValueChange = { orgName = it },
                            label = { Text(strings.organization) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = location,
                                onValueChange = { location = it },
                                label = { Text(if (isBn) "মাঠের নাম" else "Venue") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = startDate,
                                onValueChange = { startDate = it },
                                label = { Text(if (isBn) "শুরুর তারিখ" else "Start Date") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                    }
                }
            }

            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = if (isBn) "২. প্রিসেট ও নিয়মাবলি" else "2. Presets, Pitch & Format",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Text(if (isBn) "প্রিসেট বাছুন (পরে হাতে বদলানো যাবে)" else "Quick Preset (Editable afterward)", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CricketStatsEngine.TOURNAMENT_PRESETS.forEach { preset ->
                                FilterChip(
                                    selected = selectedPresetId == preset.id,
                                    onClick = {
                                        selectedPresetId = preset.id
                                        pitchType = preset.pitchType
                                        oversText = preset.oversPerMatch.toString()
                                        playersPerSideText = preset.playersPerSide.toString()
                                        squadSizeText = preset.squadSize.toString()
                                        allOutWicketsText = preset.allOutWickets.toString()
                                        allOutManuallyEdited = false
                                        maxOversPerBowlerText = preset.maxOversPerBowler.toString()
                                        rules = preset.rulesSummary
                                    },
                                    label = { Text(if (isBn) preset.labelBn else preset.labelEn) }
                                )
                            }
                        }

                        Text(if (isBn) "পিচের ধরন" else "Pitch Type", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PitchType.entries.forEach { pt ->
                                FilterChip(
                                    selected = pitchType == pt,
                                    onClick = { pitchType = pt },
                                    label = { Text(if (isBn) pt.labelBn else pt.labelEn) }
                                )
                            }
                        }

                        Text(if (isBn) "স্কোরিং ব্যবস্থা" else "Scoring Mode", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ScoringMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = scoringMode == mode,
                                    onClick = { scoringMode = mode },
                                    label = { Text(if (isBn) mode.labelBn else mode.labelEn) }
                                )
                            }
                        }

                        Text(if (isBn) "টুর্নামেন্ট ফরম্যাট" else "Tournament Format", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TournamentFormat.entries.forEach { fmt ->
                                FilterChip(
                                    selected = format == fmt,
                                    onClick = { format = fmt },
                                    label = { Text(if (isBn) fmt.labelBn else fmt.labelEn) }
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = playersPerSideText,
                                onValueChange = { raw ->
                                    val digits = raw.filter { ch -> ch.isDigit() }
                                    playersPerSideText = digits
                                    if (!allOutManuallyEdited) {
                                        val pCount = digits.toIntOrNull()
                                        if (pCount != null && pCount >= 2) {
                                            allOutWicketsText = (pCount - 1).toString()
                                        }
                                    }
                                },
                                label = { Text(if (isBn) "প্রতি দলে খেলোয়াড়" else "Players / Side") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = squadSizeText,
                                onValueChange = { squadSizeText = it.filter { ch -> ch.isDigit() } },
                                label = { Text(if (isBn) "স্কোয়াড সংখ্যা" else "Squad Size") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = oversText,
                                onValueChange = { oversText = it.filter { ch -> ch.isDigit() } },
                                label = { Text(if (isBn) "ইনিংসের ওভার" else "Innings Overs") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = allOutWicketsText,
                                onValueChange = {
                                    allOutManuallyEdited = true
                                    allOutWicketsText = it.filter { ch -> ch.isDigit() }
                                },
                                label = { Text(if (isBn) "অল-আউট উইকেট" else "All-Out Wkts") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = maxOversPerBowlerText,
                                onValueChange = { maxOversPerBowlerText = it.filter { ch -> ch.isDigit() } },
                                label = { Text(if (isBn) "বোলার সর্বোচ্চ ওভার" else "Max Ov/Bowler") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }

                        Text(if (isBn) "প্রতি জোড়া কয়বার খেলবে" else "Matches Per Pair", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(1 to (if (isBn) "১ বার" else "1x (Single)"), 2 to (if (isBn) "২ বার" else "2x (Double)")).forEach { (cnt, lbl) ->
                                FilterChip(
                                    selected = matchesPerPair == cnt,
                                    onClick = { matchesPerPair = cnt },
                                    label = { Text(lbl) }
                                )
                            }
                        }

                        Text(if (isBn) "টাই হলে কী হবে?" else "Tie Rule", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TieRule.entries.forEach { tr ->
                                FilterChip(
                                    selected = tieRule == tr,
                                    onClick = { tieRule = tr },
                                    label = { Text(if (isBn) tr.labelBn else tr.labelEn) }
                                )
                            }
                        }

                        Text(if (isBn) "প্লে-অফের ধরন ও শীর্ষ দল" else "Play-off Structure & Top Teams", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PlayoffType.entries.forEach { po ->
                                FilterChip(
                                    selected = playoffType == po,
                                    onClick = {
                                        playoffType = po
                                        playoffTeamsText = when (po) {
                                            PlayoffType.NONE -> "2"
                                            PlayoffType.FINAL_ONLY -> "2"
                                            PlayoffType.SEMI_FINAL, PlayoffType.QUALIFIER_ELIMINATOR -> "4"
                                        }
                                    },
                                    label = { Text(if (isBn) po.labelBn else po.labelEn) }
                                )
                            }
                        }
                        if (playoffType != PlayoffType.NONE) {
                            OutlinedTextField(
                                value = playoffTeamsText,
                                onValueChange = { playoffTeamsText = it.filter { ch -> ch.isDigit() } },
                                label = { Text(if (isBn) "প্লে-অফে শীর্ষ কয়টি দল যাবে" else "Top Teams Qualifying") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }

                        OutlinedTextField(
                            value = rules,
                            onValueChange = { rules = it },
                            label = { Text(if (isBn) "খেলার নিয়মাবলি" else "Match Rules") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )

                        Text(if (isBn) "পয়েন্ট পদ্ধতি (জয় / টাই / হার / পরিত্যক্ত / ওয়াকওভার)" else "Points (Win / Tie / Loss / NR / Walkover)", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedTextField(
                                value = pointsWinText,
                                onValueChange = { pointsWinText = it.filter { c -> c.isDigit() } },
                                label = { Text(if (isBn) "জয়" else "Win") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = pointsTieText,
                                onValueChange = { pointsTieText = it.filter { c -> c.isDigit() } },
                                label = { Text(if (isBn) "টাই" else "Tie") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = pointsLossText,
                                onValueChange = { pointsLossText = it.filter { c -> c.isDigit() } },
                                label = { Text(if (isBn) "হার" else "Loss") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = pointsAbandonText,
                                onValueChange = { pointsAbandonText = it.filter { c -> c.isDigit() } },
                                label = { Text(if (isBn) "NR" else "NR") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = pointsWalkoverText,
                                onValueChange = { pointsWalkoverText = it.filter { c -> c.isDigit() } },
                                label = { Text("W/O") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }

                        Text(if (isBn) "টাইব্রেকারের ক্রম (উপরে/নিচে বদলান)" else "Tiebreaker Priority (Reorder)", style = MaterialTheme.typography.labelMedium)
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            tiebreakerOrder.forEachIndexed { idx, key ->
                                val crit = runCatching { TiebreakerCriterion.valueOf(key) }.getOrNull()
                                val lbl = crit?.let { if (isBn) it.labelBn else it.labelEn } ?: key
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("${idx + 1}. $lbl", style = MaterialTheme.typography.bodyMedium)
                                    Row {
                                        IconButton(
                                            onClick = {
                                                if (idx > 0) {
                                                    val item = tiebreakerOrder.removeAt(idx)
                                                    tiebreakerOrder.add(idx - 1, item)
                                                }
                                            },
                                            enabled = idx > 0
                                        ) { Icon(Icons.Rounded.ArrowUpward, contentDescription = "Move Up") }
                                        IconButton(
                                            onClick = {
                                                if (idx < tiebreakerOrder.lastIndex) {
                                                    val item = tiebreakerOrder.removeAt(idx)
                                                    tiebreakerOrder.add(idx + 1, item)
                                                }
                                            },
                                            enabled = idx < tiebreakerOrder.lastIndex
                                        ) { Icon(Icons.Rounded.ArrowDownward, contentDescription = "Move Down") }
                                    }
                                }
                            }
                        }

                        Text(if (isBn) "পর্ব অনুযায়ী আলাদা নিয়ম (খালি রাখলে উপরের ডিফল্ট)" else "Stage-Specific Overrides (Optional — blank = Default)", style = MaterialTheme.typography.labelMedium)
                        Text(if (isBn) "লিগ / গ্রুপ পর্ব" else "League / Group Stage", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(value = leaguePlayersText, onValueChange = { leaguePlayersText = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "খেলোয়াড়" else "Players") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = leagueSquadText, onValueChange = { leagueSquadText = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "স্কোয়াড" else "Squad") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = leagueOversText, onValueChange = { leagueOversText = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "ওভার" else "Overs") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                        }
                        Text(if (isBn) "প্লে-অফ / সেমি" else "Play-off / Semi-Finals", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(value = playoffPlayersText, onValueChange = { playoffPlayersText = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "খেলোয়াড়" else "Players") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = playoffSquadText, onValueChange = { playoffSquadText = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "স্কোয়াড" else "Squad") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = playoffOversText, onValueChange = { playoffOversText = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "ওভার" else "Overs") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                        }
                        Text(if (isBn) "ফাইনাল" else "Final", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(value = finalPlayersText, onValueChange = { finalPlayersText = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "খেলোয়াড়" else "Players") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = finalSquadText, onValueChange = { finalSquadText = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "স্কোয়াড" else "Squad") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = finalOversText, onValueChange = { finalOversText = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "ওভার" else "Overs") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                        }

                        Text(if (isBn) "ম্যান অব দ্য টুর্নামেন্ট ওজন (গড়-ভিত্তিক)" else "Man of the Tournament Weights", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedTextField(value = mottBatWeightText, onValueChange = { mottBatWeightText = it }, label = { Text(if (isBn) "ব্যাট" else "Bat Wt") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = mottBowlWeightText, onValueChange = { mottBowlWeightText = it }, label = { Text(if (isBn) "বোল" else "Bowl Wt") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = mottFinalMultText, onValueChange = { mottFinalMultText = it }, label = { Text(if (isBn) "ফাইনাল×" else "Final×") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f), singleLine = true)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(value = mottWktShareText, onValueChange = { mottWktShareText = it }, label = { Text(if (isBn) "উইকেট অংশ" else "Wkt Share") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = mottEconShareText, onValueChange = { mottEconShareText = it }, label = { Text(if (isBn) "ইকোনমি অংশ" else "Econ Share") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f), singleLine = true)
                        }
                    }
                }
            }

            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = if (isBn) "৩. অংশগ্রহণকারী দল (${teamDrafts.size})" else "3. Participating Teams (${teamDrafts.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newTeamName,
                                onValueChange = { newTeamName = it },
                                label = { Text(if (isBn) "দলের নাম" else "Team Name") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = newTeamCaptain,
                                onValueChange = { newTeamCaptain = it },
                                label = { Text(if (isBn) "অধিনায়ক" else "Captain") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = newTeamGroup,
                                onValueChange = { newTeamGroup = it },
                                label = { Text("Group") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedButton(
                                onClick = {
                                    if (newTeamName.isNotBlank()) {
                                        val code = newTeamName.trim().take(3).uppercase()
                                        teamDrafts.add(
                                            TeamDraft(
                                                name = newTeamName.trim(),
                                                shortCode = code,
                                                logoEmoji = "🏏",
                                                captainName = newTeamCaptain.trim(),
                                                groupName = newTeamGroup.trim().ifBlank { "Group A" }
                                            )
                                        )
                                        newTeamName = ""
                                        newTeamCaptain = ""
                                    }
                                }
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null)
                                Text(strings.addTeam)
                            }
                        }
                    }
                }
            }

            itemsIndexed(teamDrafts) { index, draft ->
                Card(shape = RoundedCornerShape(12.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("${draft.logoEmoji} ${draft.name} (${draft.shortCode})", fontWeight = FontWeight.SemiBold)
                            Text(
                                "${draft.groupName} · Capt: ${draft.captainName.ifBlank { "TBD" }}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (teamDrafts.size > 2) {
                            IconButton(onClick = { teamDrafts.removeAt(index) }) {
                                Icon(Icons.Rounded.Delete, contentDescription = strings.delete)
                            }
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        if (name.isNotBlank() && teamDrafts.size >= 2) {
                            val pSide = playersPerSideText.toIntOrNull() ?: 11
                            viewModel.createTournament(
                                name = name,
                                logoEmoji = logoEmoji,
                                organizationName = orgName,
                                pitchType = pitchType,
                                scoringMode = scoringMode,
                                format = format,
                                oversPerMatch = oversText.toIntOrNull() ?: 20,
                                playersPerSide = pSide,
                                squadSize = squadSizeText.toIntOrNull() ?: 15,
                                allOutWickets = allOutWicketsText.toIntOrNull() ?: (pSide - 1).coerceAtLeast(1),
                                maxOversPerBowler = maxOversPerBowlerText.toIntOrNull() ?: 4,
                                groupCount = 2,
                                rulesSummary = rules,
                                pointsWin = pointsWinText.toIntOrNull() ?: 2,
                                pointsTie = pointsTieText.toIntOrNull() ?: 1,
                                pointsLoss = pointsLossText.toIntOrNull() ?: 0,
                                pointsAbandoned = pointsAbandonText.toIntOrNull() ?: 1,
                                pointsWalkover = pointsWalkoverText.toIntOrNull() ?: 2,
                                tiebreakerOrder = tiebreakerOrder.joinToString(","),
                                tieRule = tieRule,
                                matchesPerPair = matchesPerPair,
                                playoffType = playoffType,
                                playoffTeamsCount = playoffTeamsText.toIntOrNull() ?: 4,
                                leaguePlayersPerSide = leaguePlayersText.toIntOrNull() ?: 0,
                                leagueSquadSize = leagueSquadText.toIntOrNull() ?: 0,
                                leagueOvers = leagueOversText.toIntOrNull() ?: 0,
                                playoffPlayersPerSide = playoffPlayersText.toIntOrNull() ?: 0,
                                playoffSquadSize = playoffSquadText.toIntOrNull() ?: 0,
                                playoffOvers = playoffOversText.toIntOrNull() ?: 0,
                                finalPlayersPerSide = finalPlayersText.toIntOrNull() ?: 0,
                                finalSquadSize = finalSquadText.toIntOrNull() ?: 0,
                                finalOvers = finalOversText.toIntOrNull() ?: 0,
                                mottBattingWeight = mottBatWeightText.toDoubleOrNull() ?: 1.0,
                                mottBowlingWeight = mottBowlWeightText.toDoubleOrNull() ?: 1.0,
                                mottBowlingWicketShare = mottWktShareText.toDoubleOrNull() ?: 0.6,
                                mottBowlingEconomyShare = mottEconShareText.toDoubleOrNull() ?: 0.4,
                                mottFinalMultiplier = mottFinalMultText.toDoubleOrNull() ?: 1.5,
                                location = location,
                                startDateLabel = startDate,
                                teamDrafts = teamDrafts.toList(),
                                onCreated = onCreated
                            )
                        }
                    },
                    enabled = name.isNotBlank() && teamDrafts.size >= 2,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Text(strings.createTournament)
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}
