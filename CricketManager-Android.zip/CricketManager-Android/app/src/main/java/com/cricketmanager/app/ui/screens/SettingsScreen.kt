package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.ui.theme.BoundaryCrimson
import com.cricketmanager.app.viewmodel.CricketUiState
import com.cricketmanager.app.viewmodel.CricketViewModel

@Composable
fun SettingsScreen(
    uiState: CricketUiState,
    viewModel: CricketViewModel,
    onSignedOut: () -> Unit
) {
    val strings = LocalAppStrings.current
    val clipboard = LocalClipboardManager.current
    var showRestoreDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { ScreenTopBar(title = strings.settings) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(uiState.activeUser?.fullName ?: "Organizer", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(uiState.activeUser?.email ?: "", style = MaterialTheme.typography.bodySmall)
                        Text(uiState.activeUser?.organization ?: "", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(strings.languageToggle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                            SegmentedButton(
                                selected = uiState.languageCode == "BN",
                                onClick = { viewModel.setLanguage("BN") },
                                shape = SegmentedButtonDefaults.itemShape(0, 2)
                            ) { Text("বাংলা") }
                            SegmentedButton(
                                selected = uiState.languageCode == "EN",
                                onClick = { viewModel.setLanguage("EN") },
                                shape = SegmentedButtonDefaults.itemShape(1, 2)
                            ) { Text("English") }
                        }
                    }
                }
            }

            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Offline-First & Cloud Sync", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (uiState.isFirebaseConfigured) strings.syncFirebaseActive else strings.syncFirebaseMissing,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Background WorkManager Sync")
                            Switch(checked = uiState.autoSync, onCheckedChange = { viewModel.setAutoSync(it) })
                        }
                        Button(onClick = { viewModel.syncNow() }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.Sync, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(strings.syncNow)
                        }
                    }
                }
            }

            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Backup & Restore (JSON)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = {
                                    uiState.selectedTournament?.let { viewModel.exportBackup(it.id) }
                                },
                                enabled = uiState.selectedTournament != null,
                                modifier = Modifier.weight(1f)
                            ) { Text(strings.backupExport) }
                            OutlinedButton(
                                onClick = { showRestoreDialog = true },
                                modifier = Modifier.weight(1f)
                            ) { Text(strings.backupRestore) }
                        }
                    }
                }
            }

            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = if (uiState.languageCode == "BN") "ডেটা ও পরিসংখ্যান মেরামত" else "Stats & Standings Maintenance",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (uiState.languageCode == "BN") {
                                "সব টুর্নামেন্টের পুরনো ম্যাচের রেকর্ড থেকে পয়েন্ট টেবিল, NRR ও খেলোয়াড়দের স্ট্যাট নতুন করে তৈরি করুন।"
                            } else {
                                "Rebuild points tables, NRR, and all player career stats across every tournament from saved match records."
                            },
                            style = MaterialTheme.typography.bodySmall
                        )
                        OutlinedButton(
                            onClick = { viewModel.recalculateAllTournaments() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.Sync, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("সব হিসাব নতুন করে করুন")
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = { viewModel.logout(onSignedOut) },
                    colors = ButtonDefaults.buttonColors(containerColor = BoundaryCrimson),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(strings.logout)
                }
            }
        }
    }

    uiState.exportedBackupJson?.let { json ->
        AlertDialog(
            onDismissRequest = { viewModel.clearExportedJson() },
            title = { Text("Tournament Backup JSON") },
            text = {
                OutlinedTextField(
                    value = json,
                    onValueChange = {},
                    readOnly = true,
                    maxLines = 10,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    clipboard.setText(AnnotatedString(json))
                    viewModel.clearExportedJson()
                }) {
                    Icon(Icons.Rounded.ContentCopy, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Copy JSON")
                }
            },
            dismissButton = { TextButton(onClick = { viewModel.clearExportedJson() }) { Text("Close") } }
        )
    }

    if (showRestoreDialog) {
        var jsonInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = { Text(strings.backupRestore) },
            text = {
                OutlinedTextField(
                    value = jsonInput,
                    onValueChange = { jsonInput = it },
                    label = { Text("Paste exported JSON here") },
                    minLines = 6,
                    maxLines = 10,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (jsonInput.isNotBlank()) {
                        viewModel.importBackup(jsonInput)
                        showRestoreDialog = false
                    }
                }) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { showRestoreDialog = false }) { Text(strings.cancel) } }
        )
    }
}
