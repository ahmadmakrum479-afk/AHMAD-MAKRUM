package com.cricketmanager.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.i18n.stringsFor
import com.cricketmanager.app.ui.navigation.CricketManagerNavHost
import com.cricketmanager.app.ui.theme.CricketManagerTheme
import com.cricketmanager.app.viewmodel.CricketViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: CricketViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val strings = stringsFor(uiState.languageCode)

            CricketManagerTheme {
                CompositionLocalProvider(LocalAppStrings provides strings) {
                    CricketManagerNavHost(
                        uiState = uiState,
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}
