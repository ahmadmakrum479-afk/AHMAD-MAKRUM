package com.cricketmanager.app.sync

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.cricketmanager.app.data.local.CricketDatabase
import com.cricketmanager.app.data.local.UserPreferences
import com.cricketmanager.app.domain.TournamentBackupBundle
import com.google.firebase.auth.FirebaseAuth
import java.util.concurrent.TimeUnit

class TournamentSyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val db = CricketDatabase.getInstance(applicationContext)
        val dao = db.cricketDao()
        val prefs = UserPreferences(applicationContext)
        val bridge = FirebaseSyncBridge(applicationContext)

        if (!bridge.isFirebaseConfigured()) {
            prefs.setLastSyncAt(System.currentTimeMillis())
            return Result.success()
        }

        val uid = runCatching { FirebaseAuth.getInstance().currentUser?.uid }.getOrNull() ?: "offline-owner"
        val dirty = dao.getAllTournamentsOnce().filter { it.syncDirty }
        val bundles = dirty.map { t ->
            val matches = dao.getMatchesByTournamentOnce(t.id)
            TournamentBackupBundle(
                tournament = t,
                teams = dao.getTeamsByTournamentOnce(t.id),
                players = dao.getPlayersByTournamentOnce(t.id),
                matches = matches,
                balls = matches.flatMap { dao.getBallEventsForMatchOnce(it.id) },
                members = dao.getMembersByTournamentOnce(t.id),
                logs = dao.getAuditLogsOnce(t.id),
                playerMatchStats = matches.flatMap { dao.getPlayerMatchStatsOnce(it.id) }
            )
        }

        return when (bridge.pushDirtyBundles(bundles, uid)) {
            is CloudSyncResult.Synced -> {
                dirty.forEach { dao.updateTournament(it.copy(syncDirty = false)) }
                prefs.setLastSyncAt(System.currentTimeMillis())
                Result.success()
            }
            CloudSyncResult.NotConfigured -> Result.success()
            is CloudSyncResult.Error -> Result.retry()
        }
    }

    companion object {
        private const val PERIODIC_WORK_NAME = "cricket_manager_periodic_sync"
        private const val IMMEDIATE_WORK_NAME = "cricket_manager_immediate_sync"

        fun schedulePeriodicSync(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val request = PeriodicWorkRequestBuilder<TournamentSyncWorker>(6, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                PERIODIC_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }

        fun enqueueImmediateSync(context: Context) {
            val request = OneTimeWorkRequestBuilder<TournamentSyncWorker>().build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                IMMEDIATE_WORK_NAME,
                ExistingWorkPolicy.REPLACE,
                request
            )
        }
    }
}
